import java.io.IOException;
import java.util.Scanner;

public class Des_EX {
	
	public static void main(String[] args) throws IOException{
		
		String[] Subkey = new String[16]; 
		System.out.println("Data Encryption Program / Fime name: src//des.txt");
		
		FileRead file = new FileRead();
		Scanner scanner  = new Scanner(System.in);
		System.out.println("Enter 64bit Subkey:");
		String inputkey = scanner.nextLine();
		
		Subkey = Get_Subkey(inputkey);
		String Encryption_result = "";
		String Decryption_result = ""; 

		  while(true){
			  System.out.println("=========================================================================================");
			  System.out.println("<<Encryption: 'E', Decryption: 'D'");
			  System.out.println("(After 'E' or 'D')\rMake Encryption File: 'e', Make Decryption File: 'd', Quit : 'q'>>"); 
			  System.out.println("Mode�� �Է��Ͻÿ�: "); 
			  char type = scanner.next().charAt(0); // ���� �Է� �ޱ�
		   
			  if(type == 'q'){
				  System.out.println("�����մϴ�");
				  break;
			  }
		 
			  else if(type == 'E'){
				  Encryption_result = Encryption("src//des.txt", Subkey, new DES());
				  System.out.println(Encryption_result);
			  }

			  else if(type == 'D'){
				  if(Encryption_result == "") {
					  System.out.println("Encryption�� ������ �����ϴ�.");
				  }
				  else {
					  Decryption_result = Decryption(Encryption_result, Subkey, new DES());			   
					  System.out.println(Decryption_result);
				  }
			  }
			  
			  else if(type == 'e'){
				  file.MakeEncodeFile(Encryption_result);
			  }
			   
			  else if(type == 'd'){
					file.MakeDecodeFile(Decryption_result);
			  }
		  }
		  scanner.close();
	}
	
	public static String[] Get_Subkey(String inputkey) {

		Makekey key = new Makekey(inputkey);
		String[] Subkey = new String[16];
		Subkey = key.getKey();

		return Subkey;		
	}
	
	public static String Encryption(String inputfile, String[] Subkey, Encoder en) throws IOException {

		FileRead file = new FileRead();
		String encode_result = ""; 
		StringBuffer sb = file.readFile(inputfile);
		
		int k = sb.length()/8;
		int kk = sb.length()%8;

		//make 64bit block
		if(kk==0) {
			for(int i=0; i<=k; i++) {				
				String input = sb.substring(i*8, (i+1)*8);
				encode_result += en.encode(input, Subkey);
			}
		}
		else {
			for(int i=0; i<8-kk; i++) {
				sb.append(" ");
			}
			for(int i=0; i<=k; i++) {	
				String input = sb.substring(i*8, (i+1)*8);
				encode_result += en.encode(input, Subkey);
			}
		}
	
		System.out.println("Encode Successfully!!");
		return encode_result;
	}
	
	
	public static String Decryption(String inputfile, String[] Subkey, Encoder en) throws IOException {
		
		String decoded_result = "";
		
		int k = inputfile.length()/64;
		
		for(int i=0; i<k; i++) {
			String input = inputfile.substring(i*64, (i+1)*64);
			decoded_result += en.decode(input, Subkey);
		}

		System.out.println("\rDecode Successfully!!");
		
		return decoded_result;
	}

}
