import java.util.List;

public class DES extends Encoder{
	
	public String encode(String input, String[] Subkey) {

		Table table = new Table();

		String bin_input = strTobin(input);
		String IP_input = "";
		//1. init_permutation
		for(int i=0; i<64; i++) {
			 IP_input += bin_input.charAt(table.IP[i]-1);
		}
		//2. find R0,L0		
		String Left = IP_input.substring(0, 32);
		String Right = IP_input.substring(32, 64);

		//round start(L1=R0, R1=have some procedure)		
		for(int r=1; r<=16; r++) {
		
				//System.out.println("=================================== round " + r + " =========================================");
				//r++;
				//Feistel network
				
				//to find next Right, do F function
				String afterF = F_funct(Right, Subkey[r-1]);
				
				//XOR Left, before 32bit afterP value
				String XOR_result = XOR(afterF, Left, 32);//L0�� XOR����
			
				//result is NextRight
				//NextLeft is present Right
				Left = Right;
				Right = XOR_result;
	}
	
	//after 16round, find final 64bit
	String Enc_result = Right+Left;
	String final_result = "";
	
	//Lastly, IP_reverse
	for(int i=0; i<64; i++) {
		 final_result += Enc_result.charAt(table.IP_reverse[i]-1);
	}
	
	//get Final Encryption data
	return final_result;
	
	}

	
	public String decode(String encoded, String[] Subkey) {
		
		Table table = new Table();

		String result = "";
		//1. init_permutation
		String IP_input = "";
		for(int i=0; i<64; i++) {
			 IP_input += encoded.charAt(table.IP[i]-1);
		}
		
		//2. find R0,L0	
		String Left = IP_input.substring(0, 32);
		String Right = IP_input.substring(32, 64);

		//round start(L1=R0, R1=have some procedure)
		for(int r=15; r>=0; r--) {
				//System.out.println("=================================== decode round " + k + " =========================================");	
				//k++;
				//Feistel network(to find next Right, do F function)
				String afterF = F_funct(Right, Subkey[r]);
				
				//XOR Left, before 32bit afterF value
				String XOR_result = XOR(afterF, Left, 32);
				
				//XORresult is NextRight, NextLeft is present Right
				Left = Right;
				Right = XOR_result;
		}		
		//after 16round, find final 64bit
		String Enc_result = Right+Left;	
		
		//Lastly, IP_reverse
		String final_result = "";
		for(int i=0; i<64; i++) {
			 final_result += Enc_result.charAt(table.IP_reverse[i]-1);
		}

		int cc1 = Integer.valueOf(final_result.substring(0,8),2);
		int cc2 = Integer.valueOf(final_result.substring(8,16),2);
		int cc3 = Integer.valueOf(final_result.substring(16,24),2);
		int cc4 = Integer.valueOf(final_result.substring(24,32),2);
		int cc5 = Integer.valueOf(final_result.substring(32,40),2);
		int cc6 = Integer.valueOf(final_result.substring(40,48),2);
		int cc7 = Integer.valueOf(final_result.substring(48,56),2);
		int cc8 = Integer.valueOf(final_result.substring(56,64),2);
	
		result = Character.toString((char)cc1) + Character.toString((char)cc2) + Character.toString((char)cc3) + 
				Character.toString((char)cc4) + Character.toString((char)cc5) + Character.toString((char)cc6) +
				Character.toString((char)cc7) + Character.toString((char)cc8);
				
		return result;
	}

	public static String F_funct(String Right, String Subkey) {
		
		Table table = new Table();
		
		String E_R0 = "";
		for(int i=0; i<48; i++) {
			 E_R0 += Right.charAt(table.E[i]-1);
		}
			
		//Expansion_R �� Subkey XOR ����
		String xor_result = "";
		xor_result = XOR(E_R0, Subkey, 48);
		
		//s_box ġȯ
		String s1 = xor_result.substring(0, 6);
		String s2 = xor_result.substring(6, 12);
		String s3 = xor_result.substring(12, 18);
		String s4 = xor_result.substring(18, 24);
		String s5 = xor_result.substring(24, 30);
		String s6 = xor_result.substring(30, 36);
		String s7 = xor_result.substring(36, 42);
		String s8 = xor_result.substring(42, 48);
	
		int s1_row = Integer.parseInt(s1.substring(0,1) + s1.substring(5,6), 2);
		int s1_col = Integer.parseInt(s1.substring(1,5), 2);

		int s2_row = Integer.parseInt(s2.substring(0,1) + s2.substring(5,6), 2);
		int s2_col = Integer.parseInt(s2.substring(1,5), 2);
		
		int s3_row = Integer.parseInt(s3.substring(0,1) + s3.substring(5,6), 2);
		int s3_col = Integer.parseInt(s3.substring(1,5), 2);
		
		int s4_row = Integer.parseInt(s4.substring(0,1) + s4.substring(5,6), 2);
		int s4_col = Integer.parseInt(s4.substring(1,5), 2);
		
		int s5_row = Integer.parseInt(s5.substring(0,1) + s5.substring(5,6), 2);
		int s5_col = Integer.parseInt(s5.substring(1,5), 2);
	
		int s6_row = Integer.parseInt(s6.substring(0,1) + s6.substring(5,6), 2);
		int s6_col = Integer.parseInt(s6.substring(1,5), 2);
		
		int s7_row = Integer.parseInt(s7.substring(0,1) + s7.substring(5,6), 2);
		int s7_col = Integer.parseInt(s7.substring(1,5), 2);
		
		int s8_row = Integer.parseInt(s8.substring(0,1) + s8.substring(5,6), 2);
		int s8_col = Integer.parseInt(s8.substring(1,5), 2);

		String s1_value = String.format("%4s",Integer.toBinaryString(table.S1[s1_row][s1_col])).replace(' ', '0');
		String s2_value = String.format("%4s", Integer.toBinaryString(table.S2[s2_row][s2_col])).replace(' ', '0');
		String s3_value = String.format("%4s", Integer.toBinaryString(table.S3[s3_row][s3_col])).replace(' ', '0');
		String s4_value = String.format("%4s", Integer.toBinaryString(table.S4[s4_row][s4_col])).replace(' ', '0');
		String s5_value = String.format("%4s", Integer.toBinaryString(table.S5[s5_row][s5_col])).replace(' ', '0');
		String s6_value = String.format("%4s", Integer.toBinaryString(table.S6[s6_row][s6_col])).replace(' ', '0');
		String s7_value = String.format("%4s", Integer.toBinaryString(table.S7[s7_row][s7_col])).replace(' ', '0');
		String s8_value = String.format("%4s", Integer.toBinaryString(table.S8[s8_row][s8_col])).replace(' ', '0');
		String s_value = "";
		s_value = s1_value + s2_value + s3_value + s4_value + s5_value + s6_value + s7_value + s8_value;

		//permution
		String afterP = "";
		for(int i=0; i<32; i++) {
			 afterP += s_value.charAt(table.P[i]-1);
		}
		
		return afterP;
	}

	List<String> lines;
	public static String XOR(String a, String b, int l) {
		byte[] arr1 = a.getBytes();
		byte[] arr2 = b.getBytes();
		String result = "";
		
		for(int i=0; i<l; i++) {
			if(arr1[i]==arr2[i]) {
				result += "0";
			}
			else {
				result += "1";
			}
		}
		
		return result;
	}

	private static String strTobin(String input) {
		// TODO Auto-generated method stub
		byte[] bytes = input.getBytes();
		StringBuilder binary = new StringBuilder();
		for (byte b : bytes) {
			int val = b;
			for (int i = 0; i < 8; i++) {
				binary.append((val & 128) == 0 ? 0 : 1);
				val <<= 1;
			}
		}
		return binary.toString();
	}
}
