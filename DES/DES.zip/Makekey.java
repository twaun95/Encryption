
public class Makekey {

	String input;
	String Left;
	String Right;
	String[] Subkey = new String[16];
	
	Makekey(String input){
	
		if(input.length()!=8) {
			System.out.println("Please Enter 64bit value");//56��Ʈ������ ��� �ɰ��� ������ ����
			System.exit(0);
		}
		
		String binaryKey = strTobin(input);
		this.input = binaryKey.toString();
	
	}
	
	public static String shiftLeft(String str, int k) {
        String result = "";
    	result = str.substring(k);//���� �ܾ� �̾Ƴ���

        for (int i = 0; i < k; i++) {
            result += str.charAt(i);//�ڿ� �߰��ϱ�
        }
        
        return result;
    }
	
	
	private static String strTobin(String input) {
		// TODO Auto-generated method stub
		byte[] bytes = input.getBytes();
        StringBuilder binary = new StringBuilder();
        for (byte b : bytes) {
            int val = b;
            for (int i = 0; i < 8; i++) {
                  binary.append((val & 128) == 0 ? 0 : 1);
                  val <<= 1;
            }
        }
        return binary.toString();
	}
	
	public String[] getKey() {
		
		Table table = new Table();
		String Left = "";
		String Right = "";
		String permuted_input = "";	
		String afterPC2 = "";
		
		for(int i=0; i<56; i++) {
			 permuted_input += input.charAt(table.PC1[i]-1);
		}
	    
		Left = permuted_input.substring(0, 28);
	    Right = permuted_input.substring(28, 56);
	    
		for(int n=1; n<=16; n++) {
	    	
//			System.out.println("=================================== round " + n + " =========================================");
	    	Left = shiftLeft(Left, table.shiftnum[n-1]);
	    	Right= shiftLeft(Right, table.shiftnum[n-1]);        
	        String BeforePC2 = Left + Right;
	        
	        for(int i=0; i<48; i++) {
	   		 afterPC2 += BeforePC2.charAt(table.PC2[i]-1);
	        }
	        
	        this.Subkey[n-1] = afterPC2;
	        afterPC2 = "";     
	    }
		
		return Subkey;
	}
	
	public void print() {
		
		for(int i=0; i<16; i++) {
			System.out.println("Subkey_"+ (i+1) + ": " + Subkey[i]);
		}
	}
	
}
