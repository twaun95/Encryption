import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class Huffman extends Encoder implements Encodable{

	public String toString(int value) {
		return "You can encode and decode using HuffmanTree";
	}
	
	//freq,valid
	public void getList(StringBuffer sb, LinkedList<Symbol> sym) {
		
		int[] stat = new int[256];
		
		for (int i = 0 ; i < sb.length(); i++) {
			char c = sb.charAt(i);
			int c_ind = (int)c;
			stat[c_ind]++;
		}
		
		for (int i = 0; i < 256; i++) {
			Symbol s = new Symbol((char)i, stat[i]);
			sym.add(s);	
		}
		
		Collections.sort(sym); 
		Collections.reverse(sym);
	
		int min = sym.get(0).frequency;
		int min_index = 0;

		for (int i = 1 ; i < 256 ; i++) {
			
			if(min >= sym.get(i).frequency && sym.get(i).frequency!=0) {
				min = sym.get(i).frequency;
				min_index = i;
			}	
		}
		
		//freq�� 0�� �͵� ����Ʈ���� ����	
		while(sym.size() > min_index+1) {
			sym.removeLast();
		}
		
	}
	
	public void makeTree(LinkedList<Symbol> sym) {
		
		Symbol root = null;
		while(true) {
				
			Symbol s1 = sym.removeLast();

			if(sym.isEmpty()) {
				
				root = s1;
				break;
			}
			
			Symbol s2 = sym.removeLast();
			Symbol newnode = Symbol.buildUp(s1, s2);
			sym.add(newnode);
			
			Collections.sort(sym);
			Collections.reverse(sym);
		}
		
		root.labeling("");
//		System.out.println("Show character value, frequency, codeword");
//		root.printall();
	}
	
	public String encode(StringBuffer sb){

		LinkedList<Symbol> sym = new LinkedList<Symbol>();

		getList(sb, sym);
		makeTree(sym);
	
		StringBuffer result = new StringBuffer();
		for(int i=0; i<sb.length(); i++) {			
			
			char c = sb.charAt(i);
			result.append(Symbol.HuffmanTable.get(Character.valueOf(c)));
			EncodedData.add(Symbol.HuffmanTable.get(Character.valueOf(c)));
		}
		
		float ori_size = sb.length()*8;
		float com_size = result.length();
		
		System.out.println("Origin size: " + sb.length()*8 + 
				"  ->  After Compression size: " + result.length());
		System.out.println("Compression rate: " + (com_size/ori_size)*100 + "%");
		
		return result.toString();
	}
		

	static ArrayList<String> EncodedData = new ArrayList<String>();
	
	public String decode(StringBuffer sb) {

		StringBuffer result = new StringBuffer();

		for(int i=0; i<EncodedData.size(); i++) {
			result.append(Symbol.getSymbol(EncodedData.get(i)));
		}
		
		return result.toString();
	}

}