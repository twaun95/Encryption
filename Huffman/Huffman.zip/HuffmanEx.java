import java.io.IOException;

public class HuffmanEx {

	public static void main(String[] args) throws IOException {
		
		FileRead f = new FileRead();
		
		String Encode_result = Encode("src//huffman.txt", new Huffman());
		String Decode_result = Decode("src//huffman.txt", new Huffman());
		
		f.MakeEncodeFile(Encode_result);
		f.MakeDecodeFile(Decode_result);
	}

	public static String Encode(String inputfile, Encodable en) throws IOException {
		
		FileRead f = new FileRead();
		StringBuffer sb = f.readFile(inputfile);
		
		System.out.println("Encode Successfully!!");

		String result = en.encode(sb);
		return result;
	}
	
	
	public static String Decode(String inputfile, Encodable en) throws IOException {
		
		FileRead f = new FileRead();
		StringBuffer sb = f.readFile(inputfile);

		System.out.println("\rDecode Successfully!!\r");
		
		String result = en.decode(sb);
		return result;
	}

}

		
		
		
		
		
		
		
		
		
		
		
		
		
		