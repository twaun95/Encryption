public interface Encodable {
	
	public String encode(StringBuffer sb);
	public String decode(StringBuffer sb);
	
}
