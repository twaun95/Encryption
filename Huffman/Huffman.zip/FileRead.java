import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class FileRead {

	List<String> lines;

    public int readFileLines(String filePath) throws IOException {

        lines = Files.readAllLines(Paths.get(filePath) );

        StringBuffer sb = new StringBuffer();  // �׽�Ʈ�� ����

        for(String line: lines) {

            sb.append(line);

        }

        return sb.length();

    }
    
    public StringBuffer readFile(String filePath) throws IOException {

        lines = Files.readAllLines(Paths.get(filePath) );

        StringBuffer sb = new StringBuffer();  // �׽�Ʈ�� ����

        for(String line: lines) {

            sb.append(line);

        }

        return sb;

    }
    
    public void MakeDecodeFile(String str) {
		File file = new File("src//Huffman_Decoded.txt");
        FileWriter writer = null;
        
        try {
            writer = new FileWriter(file, false);
            writer.write(str);
            writer.flush();
            
            System.out.println("Make decoded text File successfully!");
            System.out.println("���ڵ� ���� �̸�: src//Huffman_Decoded.txt");
            
        } catch(IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(writer != null) writer.close();
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
	}
    
    public void MakeEncodeFile(String str) {
		File file = new File("src//Huffman_Encoded.txt");
        FileWriter writer = null;
        
        try {
            writer = new FileWriter(file, false);
            writer.write(str);
            writer.flush();
            
            System.out.println("Make encoded text File successfully!");
            System.out.println("���ڵ� ���� �̸�: src//Huffman_Encoded.txt\r");
            
        } catch(IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(writer != null) writer.close();
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
	}
    
}
